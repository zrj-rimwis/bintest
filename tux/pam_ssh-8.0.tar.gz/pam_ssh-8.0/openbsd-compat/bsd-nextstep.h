#ifndef _NEXT_POSIX_H
#define _NEXT_POSIX_H

#ifdef HAVE_NEXT
/* nothing needed */
#endif /* HAVE_NEXT */
#endif /* _NEXT_POSIX_H */

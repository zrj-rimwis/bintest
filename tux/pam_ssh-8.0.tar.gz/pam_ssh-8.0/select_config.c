#include <stdio.h>
#include <unistd.h>
#include <openssl/opensslv.h>

int main(void)
{
#if defined(LIBRESSL_VERSION_NUMBER)
	printf("Using LibreSSL config %s\n", LIBRESSL_VERSION_TEXT);
	if (symlink("config.libressl", "config.h"))
		return 1;
#elif OPENSSL_VERSION_NUMBER >= 0x10100000
	printf("Using OpenSSL config %s\n", OPENSSL_VERSION_TEXT);
	if (symlink("config.openssl-1.1", "config.h"))
		return 1;
#else
	printf("Using OpenSSL config %s\n", OPENSSL_VERSION_TEXT);
	if (symlink("config.openssl-1.0", "config.h"))
		return 1;
#endif

	return 0;
}
